/* 
 * File:   main.cpp
 * Author: Jacob Zander
 * Created on January 12, 2020, 3:14 AM
 * Purpose:
 */

//System Libraries
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    // Personal Information
    cout << "Your name\nYour address, with city, state, and ZIP code\nYour telephone number\nYour college major" << endl;

    return 0;
}



/* 
 * File:   main.cpp
 * Author: Jacob Zander
 * Created on January 12, 2020, 2:25 PM
 * Purpose:
 */

//System Libraries
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    int num1 = 50, num2 = 100, total = num1 + num2;
    cout << total << endl;
    return 0;
}


